thomas@thomas-G10AJ ~/git/packt_learning_rxjava/code_examples/ch12 $ 
